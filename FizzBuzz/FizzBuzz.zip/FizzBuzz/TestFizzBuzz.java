public class TestFizzBuzz {
    public static void main(String[] args){
        FizzBuzz resultado = new FizzBuzz();
        System.out.println("El resultado es: " + resultado.fizzBuzz(9));
    }
    
}
