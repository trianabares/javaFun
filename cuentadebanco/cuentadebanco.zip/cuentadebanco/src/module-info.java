/**
 * 
 */
/**
 * @author Triana
 *
 */
module cuentadebanco {
}