/**
 * 
 */
/**
 * @author Triana
 *
 */
module proyectoclass {
}