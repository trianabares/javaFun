public class TestPitagoras {
    public static void main(String[] args) {
        Pitagoras calculadora = new Pitagoras(); 
        double resultado = calculadora.calcularHipotenusa(6, 5);
        System.out.println("El resultado es: " + resultado);
    }
}
