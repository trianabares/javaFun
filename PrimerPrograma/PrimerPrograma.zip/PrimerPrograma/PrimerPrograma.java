public class PrimerPrograma {
    public static void main(String[] args){
        System.out.println("Vivo en San José de Mayo");
        System.out.println("Tengo 24 años de edad");
        System.out.println("Vivo en San José de Mayo");
    }
}