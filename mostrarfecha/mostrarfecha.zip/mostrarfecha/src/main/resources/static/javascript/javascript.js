function horaActual() {
    alert("Esta es la plantilla de Hora Actual");
}

function fechaActual() {
    alert("Esta es la plantilla de Fecha");
}