package com.triana.mostrarfecha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MostrarfechaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MostrarfechaApplication.class, args);
	}

}
