package com.triana.lenguajes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LenguajesApplicationTests {

	@Test
	void contextLoads() {
	}

}
