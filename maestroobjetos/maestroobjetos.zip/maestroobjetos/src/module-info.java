/**
 * 
 */
/**
 * @author Triana
 *
 */
module maestroobjetos {
}